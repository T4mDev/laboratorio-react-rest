import { useEffect, useState } from "react";
import BookService from "../services/BookService";

const emptyBook = {
  name: "",
  isbnNumber: "",
  author: "",
  publishDate: "",
  price: "",
  type: "EBOOK",
};

function BookForm({ bookToEdit, onSaved, onCancel, onMessage }) {
  const [book, setBook] = useState(emptyBook);
  const isEditing = Boolean(bookToEdit);

  useEffect(() => {
    setBook(bookToEdit ? { ...bookToEdit } : emptyBook);
  }, [bookToEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBook((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = { ...book, price: parseFloat(book.price) };

    const request = isEditing
      ? BookService.update(book.id, payload)
      : BookService.create(payload);

    request
      .then(() => {
        onMessage(
          "success",
          isEditing
            ? `Libro "${payload.name}" actualizado correctamente.`
            : `Libro "${payload.name}" creado correctamente.`
        );
        setBook(emptyBook);
        onSaved();
      })
      .catch(() => onMessage("danger", "No se pudo guardar el libro."));
  };

  return (
    <div className="card shadow-sm mb-4">
      <div className="card-header">
        <h5 className="mb-0">{isEditing ? "Editar libro" : "Nuevo libro"}</h5>
      </div>
      <form className="card-body row g-3" onSubmit={handleSubmit}>
        <div className="col-md-6">
          <label className="form-label">Nombre</label>
          <input className="form-control" name="name" value={book.name} onChange={handleChange} required />
        </div>
        <div className="col-md-6">
          <label className="form-label">ISBN</label>
          <input className="form-control" name="isbnNumber" value={book.isbnNumber} onChange={handleChange} required />
        </div>
        <div className="col-md-6">
          <label className="form-label">Autor</label>
          <input className="form-control" name="author" value={book.author} onChange={handleChange} required />
        </div>
        <div className="col-md-3">
          <label className="form-label">Fecha de publicación</label>
          <input type="date" className="form-control" name="publishDate" value={book.publishDate || ""} onChange={handleChange} required />
        </div>
        <div className="col-md-3">
          <label className="form-label">Precio</label>
          <input type="number" step="0.01" min="0" className="form-control" name="price" value={book.price} onChange={handleChange} required />
        </div>
        <div className="col-md-3">
          <label className="form-label">Tipo</label>
          <select className="form-select" name="type" value={book.type} onChange={handleChange}>
            <option value="EBOOK">EBOOK</option>
            <option value="SOFTCOPY">SOFTCOPY</option>
            <option value="HARDCOVER">HARDCOVER</option>
          </select>
        </div>
        <div className="col-12 d-flex gap-2">
          <button type="submit" className="btn btn-success">
            {isEditing ? "Actualizar" : "Guardar"}
          </button>
          {isEditing && (
            <button type="button" className="btn btn-secondary" onClick={onCancel}>
              Cancelar
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

export default BookForm;
