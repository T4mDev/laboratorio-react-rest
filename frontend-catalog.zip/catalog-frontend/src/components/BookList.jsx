import { useEffect, useState } from "react";
import BookService from "../services/BookService";

function BookList({ refreshKey, onEdit, onChanged, onMessage }) {
  const [books, setBooks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  const loadBooks = () => {
    BookService.getAll()
      .then((res) => setBooks(res.data))
      .catch(() => onMessage("danger", "No se pudo cargar la lista de libros."));
  };

  // Carga inicial (y cada vez que cambia refreshKey tras crear/editar/eliminar)
  useEffect(() => {
    loadBooks();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim() === "") {
      loadBooks();
      return;
    }
    BookService.search(searchTerm.trim())
      .then((res) => {
        // El backend responde 204 (sin contenido) si no hay coincidencias
        setBooks(res.status === 204 ? [] : res.data);
      })
      .catch(() => onMessage("danger", "Error al buscar libros."));
  };

  const handleClear = () => {
    setSearchTerm("");
    loadBooks();
  };

  const handleDelete = (book) => {
    if (!window.confirm(`¿Eliminar el libro "${book.name}"?`)) return;
    BookService.delete(book.id)
      .then(() => {
        onMessage("success", `Libro "${book.name}" eliminado correctamente.`);
        onChanged();
      })
      .catch(() => onMessage("danger", "No se pudo eliminar el libro."));
  };

  return (
    <div className="card shadow-sm">
      <div className="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <h5 className="mb-0">Catálogo de libros</h5>
        <form className="d-flex gap-2" onSubmit={handleSearch}>
          <input
            type="text"
            className="form-control"
            placeholder="Buscar por nombre..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button type="submit" className="btn btn-primary">Buscar</button>
          <button type="button" className="btn btn-outline-secondary" onClick={handleClear}>
            Limpiar
          </button>
        </form>
      </div>
      <div className="table-responsive">
        <table className="table table-striped table-hover mb-0 align-middle">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>ISBN</th>
              <th>Autor</th>
              <th>Fecha publicación</th>
              <th>Precio</th>
              <th>Tipo</th>
              <th className="text-end">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {books.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center text-muted py-3">
                  No hay libros para mostrar.
                </td>
              </tr>
            ) : (
              books.map((b) => (
                <tr key={b.id}>
                  <td>{b.id}</td>
                  <td>{b.name}</td>
                  <td>{b.isbnNumber}</td>
                  <td>{b.author}</td>
                  <td>{b.publishDate}</td>
                  <td>{b.price}</td>
                  <td>{b.type}</td>
                  <td className="text-end">
                    <button className="btn btn-sm btn-warning me-2" onClick={() => onEdit(b)}>
                      Editar
                    </button>
                    <button className="btn btn-sm btn-danger" onClick={() => handleDelete(b)}>
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default BookList;
