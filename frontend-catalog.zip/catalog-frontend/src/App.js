import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BookList from "./components/BookList";
import BookForm from "./components/BookForm";

function App() {
  const [refreshKey, setRefreshKey] = useState(0);
  const [bookToEdit, setBookToEdit] = useState(null);
  const [message, setMessage] = useState(null);

  const refresh = () => setRefreshKey((k) => k + 1);

  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 4000);
  };

  return (
    <div className="container py-4">
      <h1 className="mb-4">Gestión de Libros</h1>

      {message && (
        <div className={`alert alert-${message.type}`} role="alert">
          {message.text}
        </div>
      )}

      <BookForm
        bookToEdit={bookToEdit}
        onSaved={() => {
          setBookToEdit(null);
          refresh();
        }}
        onCancel={() => setBookToEdit(null)}
        onMessage={showMessage}
      />

      <BookList
        refreshKey={refreshKey}
        onEdit={setBookToEdit}
        onChanged={refresh}
        onMessage={showMessage}
      />
    </div>
  );
}

export default App;
