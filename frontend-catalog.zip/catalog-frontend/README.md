# catalog-frontend (React)
1. `npm install`
2. `npm start` -> http://localhost:3000 (el backend debe estar en el puerto 8080)
